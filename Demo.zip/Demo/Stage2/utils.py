import scipy.io as sio
import numpy   as np
import random
import tensorflow as tf
import scipy.io as sio
import numpy as np
Xsize=800
def Create_Pairswt(featureindex):
    # Source data
    X_train_so=sio.loadmat('/Users/wutong/Documents/linux_ie_cluster/work4/datatrip/untrip/training2000case_wecc_2class.mat')['training_features']
    X_train_source=X_train_so[:, featureindex]
    y_train_source=sio.loadmat('/Users/wutong/Documents/linux_ie_cluster/work4/datatrip/untrip/training2000case_wecc_2class.mat')['training_label']
    y_train_source = y_train_source.argmax(axis=1)+np.ones(y_train_source.shape[0])
    X_train_source=X_train_source[:2000,:]
    y_train_source=y_train_source[:2000]

    # Target data
    X_train_ta=sio.loadmat('/Users/wutong/Documents/linux_ie_cluster/work4/datatrip/Trip1001_1064/target_20sampletry_wecc_2class.mat')['trainingfea_wt']
    X_train_target=X_train_ta[:, featureindex]
    y_train_target=sio.loadmat('/Users/wutong/Documents/linux_ie_cluster/work4/datatrip/Trip1001_1064/target_20sampletry_wecc_2class.mat')['label_wt']
    y_train_target = y_train_target.argmax(axis=1)+np.ones(y_train_target.shape[0])
    y_train_target=y_train_target.reshape(y_train_target.shape[0],)
    Training_P=[]
    Training_N=[]


    for trs in range(len(y_train_source)):
        for trt in range(len(y_train_target)):
            if y_train_source[trs]==y_train_target[trt]:
                Training_P.append([trs,trt])
            else:
                Training_N.append([trs,trt])


    random.shuffle(Training_N)
    Training = Training_P+Training_N[:3*len(Training_P)]
    random.shuffle(Training)


    X1=np.zeros([len(Training),Xsize],dtype='float32')
    X2=np.zeros([len(Training),Xsize],dtype='float32')

    y1=np.zeros([len(Training)])
    y2=np.zeros([len(Training)])
    yc=np.zeros([len(Training)])

    for i in range(len(Training)):
        in1,in2=Training[i]        
        X1[i,:]=X_train_source[in1,:]
        X2[i,:]=X_train_target[in2,:]

        y1[i]=y_train_source[in1]
        y2[i]=y_train_target[in2]
        if y_train_source[in1]==y_train_target[in2]:
            yc[i]=1

    return X1, X2, y1, y2, yc

def euclidean_distance(x,y):
    eps=1e-08
    euc_dist=tf.sqrt(tf.maximum(tf.keras.backend.sum(tf.square(x - y), axis=1, keepdims=True), eps))
    return euc_dist

def contrastive_loss(y_true, y_pred):
    margin=1
    contra_loss=tf.reduce_mean(y_true * tf.square(y_pred)+ (1-y_true)* tf.square(tf.maximum(margin-y_pred, 0)))
    return contra_loss




