import tensorflow as tf
from utils import Create_Pairswt, euclidean_distance, contrastive_loss
from keras.utils import np_utils
import numpy as np
import scipy.io as sio
import random

n_input=800
n_output=2

domain_adaptation_task='Power Systems'
sample_per_class = 1
repetition = 2
net_feature=[800, 700]
net_predictor_t=[600, 500]

class DVSModel(object):
    """SVHN domain adaptation model."""

    def __init__(self, X):
        self.X_input=tf.cast(X, tf.float32)
        self._build_model()

    def _build_model(self):
        self.y = tf.placeholder("float", [None, n_output])
        self.keep_prob = 1

        #X_input = (tf.cast(self.X, tf.float32) - pixel_mean) / 255.
        X_input = self.X_input
        # CNN model for feature extraction
        with tf.variable_scope('feature_extractor'):

            weights_fea=[tf.Variable(tf.truncated_normal([n_input, net_feature[0]]) / np.sqrt(n_input))]
            for i in range(len(net_feature)-1):
                weights_fea.append(tf.Variable(tf.truncated_normal([net_feature[i], net_feature[i+1]]) / np.sqrt(net_feature[i])))
            #weights_fea.append(tf.Variable(tf.truncated_normal([net_feature[len(net_feature)-1], n_output]) / net_feature[i]))

            biases_fea=[tf.Variable(tf.ones([net_feature[0]]) * 0.05)]
            for i in range(len(net_feature)-1):
                biases_fea.append(tf.Variable(tf.ones([net_feature[i+1]]) * 0.05))
            #biases_fea.append(tf.Variable(tf.ones([n_output]) * 0.05))

            self.feature = tf.nn.dropout(X_input, self.keep_prob)
            for i in range(len(net_feature)):
                self.feature = tf.add(tf.matmul(self.feature, weights_fea[i]), biases_fea[i])   # x = wx+b
                self.feature = tf.nn.relu(self.feature)                                 # x = max(0, x)
                self.feature = tf.nn.dropout(self.feature, self.keep_prob)            # dropout layer
            self.feature_out = self.feature
                
        with tf.variable_scope('label_predictor_target'):
            
            weights_0t=[tf.Variable(tf.truncated_normal([net_feature[-1], net_predictor_t[0]]) / np.sqrt(net_feature[-1]))]
            for i in range(len(net_predictor_t)-1):
                weights_0t.append(tf.Variable(tf.truncated_normal([net_predictor_t[i], net_predictor_t[i+1]]) / np.sqrt(net_predictor_t[i])))
            weights_0t.append(tf.Variable(tf.truncated_normal([net_predictor_t[len(net_predictor_t)-1], n_output]) / net_predictor_t[i]))

            biases_0t=[tf.Variable(tf.ones([net_predictor_t[0]]) * 0.05)]
            for i in range(len(net_predictor_t)-1):
                biases_0t.append(tf.Variable(tf.ones([net_predictor_t[i+1]]) * 0.05))
            biases_0t.append(tf.Variable(tf.ones([n_output]) * 0.05))

            x1_0t = tf.nn.dropout(self.feature, self.keep_prob)
            for i in range(len(net_predictor_t)):
                x1_0t = tf.add(tf.matmul(x1_0t, weights_0t[i]), biases_0t[i])   # x = wx+b
                x1_0t = tf.nn.relu(x1_0t)                                 # x = max(0, x)
                x1_0t = tf.nn.dropout(x1_0t, self.keep_prob)            # dropout layer
            logits_t = tf.matmul(x1_0t, weights_0t[len(net_predictor_t)]) + biases_0t[len(net_predictor_t)]


            self.pred_t = tf.nn.softmax(logits_t)
            self.pred_loss_t = tf.nn.softmax_cross_entropy_with_logits(logits=logits_t,
                                                                       labels=self.y)

alpha=0.25
nb_classes=2
epoch = 20
batch_size = 256
Xa = tf.placeholder("float", [None, n_input])
Xb = tf.placeholder("float", [None, n_input])

modela = DVSModel(Xa)
modelb = DVSModel(Xb)
process_a=modela.feature_out
process_b=modelb.feature_out
distance=euclidean_distance(process_a, process_b)
distance_shape=tf.shape(distance)
label= tf.placeholder("float", [batch_size,])
#####################################
pred_loss_target = tf.reduce_mean(modela.pred_loss_t)
Loss_tot=pred_loss_target*(1-alpha)+contrastive_loss(label, distance)*alpha
target_train = tf.train.AdamOptimizer(learning_rate= 0.001).minimize(Loss_tot)
#####################################
correct_label_pred_ta = tf.equal(tf.argmax(modela.y, 1), tf.argmax(modela.pred_t, 1))
label_acc_ta = tf.reduce_mean(tf.cast(correct_label_pred_ta, tf.float32))
#####################################
correct_label_pred_tb = tf.equal(tf.argmax(modelb.y, 1), tf.argmax(modelb.pred_t, 1))
label_acc_tb = tf.reduce_mean(tf.cast(correct_label_pred_tb, tf.float32))
#####################################
featureindex= list((sio.loadmat('index.mat')['featureindex'])[0])
X1, X2, y1, y2, yc = Create_Pairswt(featureindex)



with tf.Session() as sess:
    tf.initialize_all_variables().run()
    X_test_temp=sio.loadmat('/Users/wutong/Documents/linux_ie_cluster/work4/datatrip/Trip1001_1064/training2000case_wecc_2class.mat')['training_features']
    X_test=X_test_temp[:, featureindex]
    y_test=sio.loadmat('/Users/wutong/Documents/linux_ie_cluster/work4/datatrip/Trip1001_1064/training2000case_wecc_2class.mat')['training_label']
    print ('Training the model - Epoch '+str(epoch))
    y1 = np_utils.to_categorical(y1-np.ones(y1.shape[0],), nb_classes)
    y2 = np_utils.to_categorical(y2-np.ones(y2.shape[0],), nb_classes)

    nn=batch_size
    best_Acc = 0
    for e in range(epoch):
        if e % 1 == 0:
            print(str(e)+'->')
        for i in range(int(len(y2) / nn)):
            train_Xa = X1[i * nn:(i + 1) * nn, :]
            train_Xb = X2[i * nn:(i + 1) * nn, :]
            label_a = y1[i * nn:(i + 1) * nn, :]
            label_b = y2[i * nn:(i + 1) * nn, :]
            label_c = yc[i * nn:(i + 1) * nn, ]
            loss, acc = sess.run([target_train, label_acc_ta],feed_dict={Xa: train_Xa, Xb: train_Xb, modela.y: label_a, modelb.y: label_b, label: label_c})
#            loss, acc = sess.run([target_train, label_acc_tb ],feed_dict={Xa: train_Xb, Xb: train_Xb, modela.y: label_b, modelb.y: label_b, label: label_c})
        test_acc = sess.run([label_acc_ta ],feed_dict={Xa: X_test, modela.y: y_test})
        
        print ('acc_t: %f' % test_acc[0])
        if best_Acc < test_acc[0]:
            best_Acc=test_acc[0]

print ('final_acc_t: %f' % best_Acc)





